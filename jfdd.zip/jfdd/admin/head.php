
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $CONF['web']['title'];?>-管理后台</title>

<style type="text/css">
table {
border-collapse: collapse;
border: 1px blue solid;
}

td {
  border: 1px red solid;
}
  </style>

  
  
  <mce:style type="text/css"><!--  
body {  
    font-size: 11px;  
    background:#fff;  
    font-family:Verdana, Geneva, sans-serif;  
}  
td {font-size: 11px; padding:0 5px;}  
th { background:#00004f; height:22px; color:#FFF; font-weight:normal; border-top:1px solid #000c74; border-right:1px solid #003; border-bottom:1px solid #003; border-left:1px solid #000c74; padding:0 5px;}  
.odd td { background:#333; height:22px; border-top:1px solid #444; border-right:1px solid #222; border-bottom:1px solid #222; border-left:1px solid #444; color:#FFF;}  
.even td { background:#444; height:22px; border-top:1px solid #555; border-right:1px solid #333; border-bottom:1px solid #333; border-left:1px solid #555; color:#FFF;}  
--></mce:style><style type="text/css" mce_bogus="1">body {  
    font-size: 11px;  
    background:#fff;  
    font-family:Verdana, Geneva, sans-serif;  
}  
td {font-size: 11px; padding:0 5px;}  
th { background:#00004f; height:22px; color:#FFF; font-weight:normal; border-top:1px solid #000c74; border-right:1px solid #003; border-bottom:1px solid #003; border-left:1px solid #000c74; padding:0 5px;}  
.odd td { background:#333; height:22px; border-top:1px solid #444; border-right:1px solid #222; border-bottom:1px solid #222; border-left:1px solid #444; color:#FFF;}  
.even td { background:#444; height:22px; border-top:1px solid #555; border-right:1px solid #333; border-bottom:1px solid #333; border-left:1px solid #555; color:#FFF;}</style>  
</head>