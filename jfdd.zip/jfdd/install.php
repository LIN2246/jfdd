<?php

/* 跳转到后台 */


header("Location: ./install/install.php");


?>