<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="copyright" content="<?php echo $CONF['web']['copyright'];?>"> 
<meta type="keywords" content="<?php echo $CONF['web']['keyword'];?>">
<meta type="description" content="<?php echo $CONF['web']['description'];?>">



<title><?php echo $CONF['web']['title'];?></title>
<link type="text/css" href="images/css/jfstyle.css" rel="stylesheet" />
<script type="text/javascript" src="images/js/jfdd.js"></script>
<script src="images/js/jquery.js"></script>
<script src="images/js/jquery.validator.js"></script>
<script src="images/js/jquery.corners.min.js"></script>





</head>